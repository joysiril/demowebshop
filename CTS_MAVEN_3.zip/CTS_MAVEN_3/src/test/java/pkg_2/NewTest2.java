package pkg_2;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewTest2 {
  @Test
  public void f() {
	  System.out.println("in testing");
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	  WebDriver dr=new ChromeDriver();
//	  System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
//	  WebDriver dr=new FirefoxDriver();
	  dr.get("https://www.saucedemo.com");
	  
  }
}
