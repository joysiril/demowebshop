package pkg_2;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pkg_java2.DriverFactory;

public class browser_test extends DriverFactory{
	
	String url="http://demowebshop.tricentis.com/login";
	WebDriver dr;
	
  @Test
  public void chrome_login() {
	  dr=DriverFactory.launch_browser("FIREFOX",url);
  }
}
