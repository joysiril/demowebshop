package pkg_java2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class mainwaits {
	
	static WaitTypes wt;
	static WebDriver dr;
	public void  login(String eid,String pwd)
	{
		wt=new WaitTypes(dr);
		String a_result;
		
		By by_eid=By.xpath("//input[@class='email']");
		WebElement we_eid=wt.waitForElement(by_eid,20);
	}

}
