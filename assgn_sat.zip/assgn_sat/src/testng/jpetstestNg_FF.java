package testng;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.Loginpage;
import utilities.libtray;
import excel_read.REadrow;


public class jpetstestNg_FF extends REadrow {

static WebDriver Ar;
libtray util;

String RM="Your account has been created. Please try login !!";
@BeforeClass
public void launchBrowser()
{

getdata();
util=new libtray(Ar);
util.update_log("completed reading from excel");
// String url="https://jpetstore.cfapps.io/login";
//  Ar= Utilites.DriveBrowser.Launch_browser("FIREFOX", url);
}
 
  @Test(dataProvider="logindata")
  public void Login(String username,String pwd)
  {
 System.out.println(username+" "+pwd );
 String url="https://jpetstore.cfapps.io/login";
      Ar= utilities.DriveBrowser.Launch_browser("FIREFOX", url);
 Loginpage L=new Loginpage(Ar);
 L.loginstart(username,pwd);
 util=new libtray(Ar);
 util.update_log("FIREFOX browser launched successfully");
 Ar.close();
   
  }
 
 
  @DataProvider(name="logindata")
  public String[][] Provide_data()
  {
 return testdata;
  }

}

