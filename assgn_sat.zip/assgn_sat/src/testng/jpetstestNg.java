package testng;

import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.Loginpage;
import utilities.libtray;
import excel_read.REadrow;


public class jpetstestNg extends REadrow {

static WebDriver dr;
	libtray util;

String RM="Your account has been created. Please try login !!";
@BeforeClass
public void launchBrowser()
{
getdata();
util=new libtray(dr);
util.update_log("completed reading from excel");
// String url="https://jpetstore.cfapps.io/login";
//  Ar= Utilites.DriveBrowser.Launch_browser("FIREFOX", url);
}
 
  @Test(dataProvider="logindata")
  public void Login(String username,String pwd)
  {
 System.out.println(username+" "+pwd );
 String url="https://jpetstore.cfapps.io/login";
      dr= utilities.DriveBrowser.Launch_browser("CHROME", url);
 Loginpage L=new Loginpage(dr);
 L.loginstart(username,pwd);
 util=new libtray(dr);
 util.update_log("Chrome browser launched successfully");
 dr.close();
   
  }
 
 
  @DataProvider(name="logindata")
  public String[][] Provide_data()
  {
 return testdata;
  }

}
