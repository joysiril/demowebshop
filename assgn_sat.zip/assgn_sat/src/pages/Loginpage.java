package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.libtray;

public class Loginpage {


WebDriver dr;

By Usr1name=By.xpath("//input[@name='username']");
By passname=By.xpath("//input[@name='password']");
By btn=By.xpath("//input[@id='login']");

By matchlogin=By.xpath("//div[@id='WelcomeContent']");
libtray ut1;
public Loginpage(WebDriver dr)
{
this.dr=dr;
ut1=new libtray(dr);

}
public void Set_user1(String username)
{
WebElement usr1=ut1.waitforElements(Usr1name, 20);
usr1.sendKeys(username);
}
public void Set_pwd1(String Pwdname)
{
WebElement pwd1=ut1.waitforElements(passname, 20);
pwd1.sendKeys(Pwdname);
}
public void BTn_click()
{
WebElement BTn1=ut1.waitforElements(btn, 20);
BTn1.click();
}

public void loginstart(String nmae,String pwdname1)
{
this.Set_user1(nmae);
this.Set_pwd1(pwdname1);
this.BTn_click();
}

}

