package STEP_DEF_PKG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class cucum {
	
	WebDriver dr;
	String a_title,e_title="Demo Web Shop",a_name,e_name="joysiril.m@gmail.com",test_result,
			xp="//a[@href='/customer/info']";
	
	@Given("^Browser is launched & login page displayed$")
	public void browser_is_launched_login_page_displayed() throws Throwable {
	  System.out.println("browser_is_launched_login_page_displayed");
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	  dr= new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/login");
	}

	@When("^User enters login credentials & click on login$")
	public void user_enters_login_credentials_click_on_login() throws Throwable {
	   System.out.println("user_enters_login_credentials_click_on_login");
	   dr.findElement(By.xpath("//input[@class='email']")).sendKeys("joysiril.m@gmail.com");
	   dr.findElement(By.xpath("//input[@class='password']")).sendKeys("Joysiril@30");
	   dr.findElement(By.xpath("//input[@value='Log in']")).click();
	}

	@Then("^Successful login happens & profile name displayed correctly$")
	public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
		System.out.println("successful_login_happens_profile_name_displayed_correctly");
		a_title=dr.getTitle();
		a_name=dr.findElement(By.xpath(xp)).getText();
		//if(a_title.equals(e_title)) 
		if(a_name.equals(e_name) && a_title.equals(e_title))
		{
			test_result="pass";
		}
		else
		{
			test_result="fail";
		}
		System.out.println("test_result: " +test_result);
	}

}
