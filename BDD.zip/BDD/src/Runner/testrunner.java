package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="features",glue="STEP_DEF_PKG")

public class testrunner extends AbstractTestNGCucumberTests {

}
