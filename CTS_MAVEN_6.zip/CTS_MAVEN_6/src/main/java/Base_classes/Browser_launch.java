package Base_classes;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browser_launch {
protected WebDriver dr;

  // String path="src\\test\\resources\\Drivers\\chromedriver.exe";
	public  WebDriver Launch_browser(String browser,String url)
	{
	
		if(browser.contains("chrome"))
	{
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\Drivers\\chromedriver.exe");
		dr=new ChromeDriver();
	}
		else if(browser.contains("firefox"))
		{
		System.setProperty("webdriver.gecko.driver","geckodriver.exe");
		dr=new FirefoxDriver();
		}

	dr.get(url);
	dr.manage().window().maximize();
	dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);


		return dr;
	}

}
