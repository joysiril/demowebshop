package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Waits;

public class BMW_techdata {
	
	WebDriver dr;
	Waits wat;
	
	By tech=By.xpath("/html/body/div[5]/main/div[1]/div[5]/div/div/div/div/div/div[4]/nav/div/div[3]/a");
	By spd=By.xpath("/html/body/div[5]/main/div[1]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[2]/div/table/tbody/tr[1]/td[2]/div");
	public BMW_techdata(WebDriver dr)
	{
		this.dr=dr;
		wat=new Waits(dr);
	}
	
	public void tdata()
	{
		WebElement td=wat.waitToClickable(tech, 20);
		td.click();
	}
	
	public int speed()
	{
		String s=dr.findElement(spd).getText();
		int n=Integer.parseInt(s);
		System.out.println(n);
		return n;
		
	}
 
	public void verify()
	{
		this.tdata();
		this.speed();
	}
}
