package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Waits;

public class BMW_models {
	
	WebDriver dr;
	Waits wat;
	
	By mdl=By.xpath("/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[1]/div/div[1]/a");
	By num=By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[1]/div/nav/div/div/div[4]/a");
	By img=By.xpath("/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/img");
	By fnd=By.xpath("/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[3]/div/a/div");

	public BMW_models(WebDriver dr)
	{
		this.dr=dr;
		wat=new Waits(dr);
	}
 
	public void model()
	{
		WebElement md=wat.waitToClickable(mdl,20);
		md.click();
	}
	
	public void numb()
	{
		WebElement nm=wat.waitToClickable(num,20);
		nm.click();
	}
	
	public void image()
	{
		WebElement ig=wat.waitToClickable(img,20);
		ig.click();
	}
	
	public void find()
	{
		WebElement fn=wat.waitforElements(fnd,20);
		fn.click();
	}
	
	public void do_oprtns()
	{
		this.model();
		this.numb();
		this.image();
		this.find();
	}
}
