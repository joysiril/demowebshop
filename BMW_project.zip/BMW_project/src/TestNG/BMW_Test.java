package TestNG;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.BMW_models;
import Pages.BMW_techdata;
import Utilities.Browser_launch;

public class BMW_Test {
	WebDriver dr;
	Browser_launch blnch;
	BMW_models bmd;
	BMW_techdata dtech;
	
	@BeforeClass
	public void browserlaunch()
	{
		blnch=new Browser_launch();
		dr=blnch.launch_browser();
	}
	
  @Test(priority=1)
  public void t1() {
	  bmd=new BMW_models(dr);
	  bmd.do_oprtns();
  }  
	  @Test(priority=2)
	  public void t2() {	  
	  dtech=new BMW_techdata(dr);
	  dtech.verify();
  }
	 
	  @Test(priority=3)
	  public void t3() {	  
	  dtech=new BMW_techdata(dr);
	  dtech.verify();
	//int act_speed=dtech.speed();
	 // Assert.assertTrue(act_speed.contains(250));
	  
  }
}
