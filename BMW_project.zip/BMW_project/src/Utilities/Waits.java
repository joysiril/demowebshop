package Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waits {
	
	WebDriver dr;
	
	public Waits (WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebElement waitforElements(By locator, int timeout)
	{
		try {
			WebDriverWait wt=new WebDriverWait(dr,timeout);
			WebElement wb=wt.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return wb;
		}catch (Exception e)
		{
		return null;
		}
	}
	
	public WebElement waitToClickable(By locator, int timeout)
	{
		try {
			WebDriverWait wt=new WebDriverWait(dr,timeout);
			WebElement wb=wt.until(ExpectedConditions.elementToBeClickable(locator));
			return wb;
		}catch(Exception e)
		{
		return null;
		}
		
	}
}
