package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser_launch {

	WebDriver dr;
	
	public WebDriver launch_browser() {
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("https://www.bmw.in/en/");
		return dr;
	}
	
}
