package Base_classes;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

public class Wrappers {
	
	WebDriver dr;
	
	public WebDriver browser_launch(String browser,String url)
	{
	
			switch(browser)
			{
			case "CHROME":
				String   downloadPath = System.getProperty("user.dir") + File.separator + "downloads";
				System.out.println(downloadPath);

				// setting download path directory
				Map<String, String> prefs = new HashMap<String, String>();
				prefs.put("download.default_directory", downloadPath);

				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", prefs);
				
				//launching the browser
				System.setProperty("webdriver.chrome.driver","chromedriver.exe");
				dr=new ChromeDriver(options);
				break;
				
			case "FIREFOX":
				System.setProperty("webdriver.gecko.driver","geckodriver.exe");
				dr=new FirefoxDriver();
				break;		
				
		}
			dr.get(url);
			dr.manage().window().maximize();  //maximizing the window
			dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //implicity wait
		return dr;
	}
}
