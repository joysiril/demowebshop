package Test_classes;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base_classes.Wrappers;
import Page_classes.Page1_selenium;
import Page_classes.Page2_IE_download;

public class Testpage_selenium extends Wrappers {
	
	WebDriver dr; 
	Wrappers lnch;
	Page1_selenium sel;
	Page2_IE_download ied;
	
	//url of the page
	String url="https://www.seleniumhq.org";
	
	@BeforeClass
	//Launching the browser
	public void b_launch()
	{
		lnch=new Wrappers();
		dr=lnch.browser_launch("CHROME",url);
		System.out.println("launched");
	}
  @Test(priority=1)
  public void test1() throws InterruptedException {
	  sel=new Page1_selenium(dr); //calling the 'Page1_selenium' from 'Page_classes'
	  sel.dwn_tab(); //clicking on the download tab
	  System.out.println("Directed to download page");
  }
  
  @Test(priority=2)
  public void test2() throws InterruptedException
  {
	  ied=new Page2_IE_download(dr);//calling the 'Page2_IE_download' from 'Page_classes'
	  ied.dwn_windows(); //Click to download the '64 bit Windows IE'
	  
	  //Setting download directory path
	  String   downloadPath = System.getProperty("user.dir") + File.separator + "downloads";
	  File f=new File(downloadPath+ "\\IEDriverServer_x64_3.150.1.zip");
	  
	  System.out.println(f);
	  
	  boolean b=f.exists();
	  System.out.println(b);
	  //Checking the existence of the download zip file using Assert
	  if(b==true)
	  {
		  Assert.assertTrue(b, "64 bit Windows IE downloaded successfully");
		  //File exists in the path then the below message print
		  System.out.println("IE_download successfully");
	  }
	  else {
		  Assert.assertTrue(b,"64 bit Windows IE downloaded not successful");
		  //File not exists then the below message print
		  System.out.println("IE_download not successful");
	  }
  }
  
 @AfterClass
 public void b_close()
 {
	 dr.close(); //close the browser
 }
}
