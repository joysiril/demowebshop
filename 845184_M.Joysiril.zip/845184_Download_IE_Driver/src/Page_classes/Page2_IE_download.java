package Page_classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page2_IE_download {
	
	WebDriver dr;
	
	//locator for the 64 bit Windows IE
	By wdws=By.xpath("//p//a[@href='https://selenium-release.storage.googleapis.com/3.150/IEDriverServer_x64_3.150.1.zip'][1]");
	
	public Page2_IE_download(WebDriver dr)
	{
		this.dr=dr;
	}
	
	//Method for clicking the 64 bit Windows IE
	public void dwn_windows() throws InterruptedException
	{
		dr.findElement(wdws).click();
		Thread.sleep(2000);
	}
	
}
