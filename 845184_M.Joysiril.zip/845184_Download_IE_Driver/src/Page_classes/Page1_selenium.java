package Page_classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page1_selenium {
	
	WebDriver dr; 
	
	//locator for the download tab
	By dwn=By.xpath("//a[@class='nav-item'][1]");
	
	public Page1_selenium(WebDriver dr)
	{
		this.dr=dr;
	}
	
	//Method for clicking the download tab
	public void dwn_tab() throws InterruptedException
	{
		dr.findElement(dwn).click();
		Thread.sleep(2000);
	}

}
