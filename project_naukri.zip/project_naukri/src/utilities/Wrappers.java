package utilities;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import excel_read.REadrow;

public class Wrappers extends REadrow{
	
 protected static WebDriver dr;
	
	public WebDriver browser_launch(String browser,String url)
	{
	
			switch(browser)
			{
			case "CHROME":
				System.setProperty("webdriver.chrome.driver","chromedriver.exe");
				dr=new ChromeDriver();
				break;
				
			case "FIREFOX":
				System.setProperty("webdriver.gecko.driver","geckodriver.exe");
				dr=new FirefoxDriver();
				break;		
				
		}
			dr.get(url);
			dr.manage().window().maximize();  
			dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		return dr;
	}
                                                                                   
}


