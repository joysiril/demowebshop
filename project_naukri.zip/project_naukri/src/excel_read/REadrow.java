package excel_read;

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;

	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	public class REadrow {
	protected static String[][] testdata =new String[2][5];

	public static void getdata() {

	//System.out.println("joy");


	try {
	File f=new File("C:\\Users\\BLTuser.BLT0208\\Desktop\\new\\Naukri.xlsx");
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet("Sheet1");
	int r1=1;
//	for(int r1=1;r1<=3;r1++ )
//	{
	for(int c=0;c<=4;c++)
	{
	XSSFRow row=sh.getRow(r1);
	XSSFCell cell1 =row.getCell(c);

	testdata[r1][c] =cell1.getStringCellValue();
	System.out.println(testdata[r1][c]);
	}

	 }catch (FileNotFoundException e) {

	e.printStackTrace();
	} catch (IOException e) {

	e.printStackTrace();
	}

	}

	}



