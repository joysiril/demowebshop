package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import excel_read.REadrow;
import pages.Naukri_edu;
import pages.Naukri_login;
import pages.Naukri_register;
import utilities.Wrappers;

public class Test_naukri extends Wrappers {
	
	WebDriver dr;
	Wrappers lnch;
	Naukri_login login;
	Naukri_register regis;
	Naukri_edu educ;
	REadrow l;
	String url="https://www.naukri.com/";
	
	@BeforeClass
	public void launch() {
		lnch=new Wrappers();
		dr=lnch.browser_launch("CHROME",url);
		  l.getdata();
	
	}
  @Test
  public void test_login() throws InterruptedException {
	  login=new Naukri_login(dr);
	  login.do_login();   
  }
  
  @Test(dataProvider="logindata")
  public void test_regis(String n,String e,String p,String m,String c)
  {
	 regis=new  Naukri_register(dr);
	 String num=m.substring(1, 10);
	 regis.do_regis(n,e,p,num,c);
  }
  @Test
  public void test_dtls()  {
	  educ=new Naukri_edu(dr);
	  educ.details();
  }
  
  
  
  @DataProvider(name="logindata")
  public String[][] Provide_data()
  {
	  System.out.println("read excel");
 return testdata;
  }
//	@AfterClass
//	public void b_close()
//	{
//		dr.close();
//	}
}