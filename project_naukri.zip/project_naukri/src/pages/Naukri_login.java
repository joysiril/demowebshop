package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Naukri_login {
	
	WebDriver dr;
	
	By logn=By.xpath("//a[@title='Jobseeker Login']");
	By reg=By.xpath("/html/body/div[10]/div[2]/div[2]/form/div[10]/a");
	By frs=By.xpath("//button[@value='fresher']");
	
	public Naukri_login(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void login() throws InterruptedException
	{
		dr.findElement(logn).click();
		Thread.sleep(2000);
	}
	
	public void regis() throws InterruptedException
	{
		dr.findElement(reg).click();
		Thread.sleep(2000);
	}
	 
	public void fresher() throws InterruptedException
	{
		dr.findElement(frs).click();
		Thread.sleep(2000);
	}
	public void do_login() throws InterruptedException
	{
		this.login();
		this.regis();
		this.fresher();
	}

}
