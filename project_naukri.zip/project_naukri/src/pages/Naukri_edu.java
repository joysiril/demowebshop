package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Naukri_edu {
	
	WebDriver dr;
	
	By hqu=By.xpath("//input[@name='qualification_0']");
	By cur=By.xpath("//input[@name='course_0']");
	By spz=By.xpath("//input[@name='spec_0']");
	By unv=By.xpath("//input[@name='institute_0']");
	By typ=By.xpath("//label[@for='couseType_full_0']");
	By psy=By.xpath("//input[@name='passingYear_0']");
	By skl=By.xpath("//input[@name='keyskills']");
	By bun=By.xpath("//button[@name='submitEducationDetail']");
	
	public Naukri_edu(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void hqualif()
	{
		dr.findElement(hqu).click();
		//html/body/main/div/div/form/edu-section/section[1]/edu-qualification/div/div[1]/div/div/div[2]
		WebElement we1=dr.findElement(By.xpath("////*[@id=\"educationDetailForm\"]/edu-section/section[1]/edu-qualification/div/div[1]/div/div/div[2]/ul/li"));
		Actions actions=new Actions(dr);
		actions.moveToElement(we1).pause(1000).click().build().perform();
		// //*[@id="educationDetailForm"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]
	}
	
	public void course()
	{
		dr.findElement(cur).click();
		WebElement we1=dr.findElement(By.xpath("/html/body/main/div/div/form/edu-section/section[1]/div/edu-course/div/div[1]/div/div[1]/div[2]/ul/li"));
		Actions actions=new Actions(dr);
		actions.moveToElement(we1).pause(1000).click().build().perform();
	}
	
	public void details()
	{
		this.hqualif();
		this.course();
	}
}
