package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Naukri_register {
 
	WebDriver dr;
	
	By nme=By.xpath("//input[@name='fname']");
	By eml=By.xpath("//input[@name='email']");
	By psd=By.xpath("//input[@name='password']");
	By num=By.xpath("//input[@name='number']");
	By cty=By.xpath("/html/body/main/div/div/form/resman-location/div/div/div[1]/div/div[1]/ul/li/div/label/input");
	By btn=By.xpath("//button[@name='basicDetailSubmit']");

	public Naukri_register(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void name(String nm)
	{
		dr.findElement(nme).sendKeys(nm);
	}
	public void email(String em)
	{
		dr.findElement(eml).sendKeys(em);
	}
	public void pswd(String pd)
	{
		dr.findElement(psd).sendKeys(pd);
	}
	public void number(String nb)
	{
		dr.findElement(num).sendKeys(nb);
	}
	public void city(String ct)
	{
		dr.findElement(cty).sendKeys(ct);
//		dr.findElement(cty).click();
		
//		WebDriverWait wt=new WebDriverWait(dr,10);
//		WebElement we=wt.until(ExpectedConditions.elementToBeClickable(cty));
//		we.click();
		// /html/body/main/div/div/form/resman-location/div/div/div[1]/div/div[2]
//		Actions actions=new Actions(dr);
//
//		//From
//		dr.findElement(cty).click();
//		actions.pause(1000).sendKeys("tir").pause(5000).build().perform();
			WebElement we1=dr.findElement(By.xpath("/html/body/main/div/div/form/resman-location/div/div/div[1]/div/div[2]"));
			Actions actions=new Actions(dr);
			actions.moveToElement(we1).pause(1000).click().build().perform();
	}
	public void clk_btn()
	{
		dr.findElement(btn).click();
	}
	
	public void do_regis(String n,String e,String p,String m, String c)
	{
		this.name(n);
		this.email(e);
		this.pswd(p);
		this.number(m);
		this.city(c);
		this.clk_btn();
		
	}

	
}
