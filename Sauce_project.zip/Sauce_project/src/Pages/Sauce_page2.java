package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Sauce_page2 {
	WebDriver dr;
	
	By flt=By.xpath("//select[@class='product_sort_container']");
	By srt=By.xpath("//option[@value='az']");
	By clk=By.xpath("//div[@class='pricebar'][1]//child::button[1]");
	By abt=By.xpath("//div[@class='bm-burger-button']");
	By about=By.xpath("//a[@id='about_sidebar_link']");
	By prc=By.xpath("//div[@data-hover-content='Pricing']");
	public Sauce_page2(WebDriver dr)
	{
		this.dr=dr;
	}
	 
	public void filter()
	{
		dr.findElement(flt).click();
	}
	public void sort()
	{
		dr.findElement(srt).click();
	}
	public void btn_clk()
	{
		dr.findElement(clk).click();
	}
	public void abt_clk()
	{
		dr.findElement(abt).click();
	}
	public void about_clk()
	{
		dr.findElement(about).click();
	}
	 public void pricing()
	 {
		 dr.findElement(prc).click();
	 }
	public void verify()
	{
		this.filter();
		this.sort();
		this.btn_clk();
		this.abt_clk();
		this.about_clk();
		this.pricing();
	}
}
