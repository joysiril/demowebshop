package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Sauce_page1 {
	
	WebDriver dr;
	
	By usn=By.xpath("//input[@type='text']");
	By pwd=By.xpath("//input[@type='password']");
	By btn=By.xpath("//input[@type='submit']");
	 
	public Sauce_page1(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void username(String un)
	{
		dr.findElement(usn).sendKeys(un);
		
	}
	
	public void password(String pd)
	{
		dr.findElement(pwd).sendKeys(pd);
		
	}
	public void clk_btn() 
	{
		dr.findElement(btn).click();
	
	}
	 public void login(String u,String p) 
	 {
		 this.username(u);
		 this.password(p);
		 this.clk_btn();
	 }
}
