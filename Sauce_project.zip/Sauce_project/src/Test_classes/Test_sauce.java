package Test_classes;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base_classes.Wrappers;
import Excel.excel_Read;
import Pages.Sauce_page1;
import Pages.Sauce_page2;

public class Test_sauce extends Wrappers{
	 WebDriver dr;
	Wrappers wrp;
	Sauce_page1 sau;
	Sauce_page2 sap; 
	excel_Read exl;
	String url="https://www.saucedemo.com/";

@BeforeClass
public void launch()
{
	new Wrappers();
	dr=wrp.Launch_browser("CHROME",url);
	exl.getdata();
}
	
  @Test(dataProvider="logindata")
  public void t1(String u,String p) {
	  sau=new Sauce_page1(dr);
	  sau.login(u,p);
	  System.out.println("pass");
  }
  
  @Test
  public void t2() {
	  sap=new Sauce_page2(dr);
	  sap.verify();
	  System.out.println("pass2");
  }
  @DataProvider(name="logindata")
  public String[][] Provide_data()
  {
	  System.out.println("read excel");
 return testdata;
  }
}
