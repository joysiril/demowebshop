package Assessment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Tuxedo {

	WebDriver dr;
	WebElement we;
	By xp=By.xpath("//div[@class='sortBy_block fl'][1]//child::a[contains(@id,'sbSelector')]");
	
	public Tuxedo(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void srch_prdts()
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("tuxedo");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		//xp=dr.findElement(By.xpath("//div[@class='sortBy_block fl'][1]//child::a[contains(@id,'sbSelector')]")).click();
		WebDriverWait wt=new WebDriverWait(dr,20);
		we=wt.until(ExpectedConditions.elementToBeClickable(xp));
		we.click();
		dr.findElement(By.xpath("//a[@href='#Price High-Low']")).click();
		dr.findElement(By.xpath("//p[@rel='/product/prd-1688320/chaps-classic-fit-black-tuxedo-jacket-men.jsp?prdPV=1']")).click();
		dr.findElement(By.xpath("//select[@id='size-dropdown']")).click();
		dr.findElement(By.xpath("//option[@value='42 SHORT']")).click();
		
		
	}
	
	
	
}
