package Assessment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BMW_cars {
	
	WebDriver dr;
	WebElement we;
	
	//By mdl=By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[2]/div/div[1]/div/div[2]/div/div/div/div/div[1]/div/nav/div/div/div[4]");
	
	public BMW_cars(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void models_sch()
	{
		dr.findElement(By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[1]/div/div[1]/div[1]/div/div[1]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[2]/div/div[1]/div/div[2]/div/div/div/div/div[1]/div/nav/div/div/div[4]")).click();
		
//		WebDriverWait wt=new WebDriverWait(dr,20);
//		we=wt.until(ExpectedConditions.elementToBeClickable(mdl));
//		we.click();
		dr.findElement(By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[2]/div/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[1]/div/div")).click();
		
	}

}
