package Assessment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Php_travels {
	
	WebDriver dr;
	
	public Php_travels(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void book_flight()
	{
		dr.findElement(By.xpath("//div[@class='dropdown dropdown-currency']")).click();
		dr.findElement(By.xpath("//a[@data-code='11']")).click();
		
	}

}
