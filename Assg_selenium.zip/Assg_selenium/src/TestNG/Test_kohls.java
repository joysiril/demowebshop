package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Assessment.Tuxedo;

public class Test_kohls {
	
	WebDriver dr;
	Tuxedo tux;
	
	@BeforeMethod
	public void bm(){
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("https://www.kohls.com/");
		tux=new Tuxedo(dr);
	}
		
  @Test
  public void t1() {
	  tux.srch_prdts();
	  
  }
}
