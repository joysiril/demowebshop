package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Assessment.BMW_cars;

public class BMW_Test {
	
	WebDriver dr;
	BMW_cars bcars;
 
	@BeforeClass
	public void launch_browser()
	{
		System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("https://www.bmw.in/en/");
		bcars=new BMW_cars(dr);
	}
	
	@Test
  public void t1() {
		bcars.models_sch();
  }
}
