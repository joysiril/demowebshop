package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Assessment.Php_travels;
import Assessment.Tuxedo;

public class Test_php {
	
	WebDriver dr;
	Php_travels php;
	
	@BeforeMethod
	public void bm(){
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("https://www.kohls.com/");
		php=new Php_travels(dr);
	}
		
  @Test
  public void t1() {
  }
	  
}
